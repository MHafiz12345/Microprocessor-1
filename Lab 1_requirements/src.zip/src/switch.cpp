    #include <avr/io.h>

    // initSwitch returns void and takes no parameters
    void initSwitch(){
        // Configure pin 22 (PORTA pin 0) as input
        DDRA &= ~(1 << DDA0);  // Clear the bit to set as input
        
        // Optional: Enable internal pull-up resistor
        PORTA |= (1 << PORTA0);  // Set the bit to enable pull-up resistor
    }