#include <avr/io.h>
#include <util/delay.h>
#include "led.h"
#include "switch.h"

int main() {
    initLED();
    initSwitch();
    
    while(1) {
        // Forward sequence (0 to 3)
        for(unsigned int i = 0; i < 4; i++) {
            runLED(i);
            if(!(PINA & (1 << PINA0))) {
                _delay_ms(1000);
            } else {
                _delay_ms(100);
            }
        }
        
        // Backward sequence (2 to 0)
        for(unsigned int i = 2; i > 0; i--) {
            runLED(i);
            if(!(PINA & (1 << PINA0))) {
                _delay_ms(1000);
            } else {
                _delay_ms(100);
            }
        }
    }
    return 0;
}